﻿namespace Jardineria
{
    partial class Detalles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comentarios = new System.Windows.Forms.TextBox();
            this.fechaEsperada = new System.Windows.Forms.DateTimePicker();
            this.TxtFecha = new System.Windows.Forms.Label();
            this.TxtComentario = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.TxtCliente = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BotonAgregar = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.FormPedidosTitle = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LabelTotal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LabelIva = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.LavelTotalIva = new System.Windows.Forms.Label();
            this.BotonFinalizar = new System.Windows.Forms.Button();
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.InputCantidad = new System.Windows.Forms.NumericUpDown();
            this.fechaPedido = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.estadoPedido = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Fechas = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputCantidad)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.Fechas.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // comentarios
            // 
            this.comentarios.Location = new System.Drawing.Point(124, 53);
            this.comentarios.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comentarios.Name = "comentarios";
            this.comentarios.Size = new System.Drawing.Size(194, 20);
            this.comentarios.TabIndex = 0;
            // 
            // fechaEsperada
            // 
            this.fechaEsperada.Location = new System.Drawing.Point(143, 52);
            this.fechaEsperada.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fechaEsperada.Name = "fechaEsperada";
            this.fechaEsperada.Size = new System.Drawing.Size(102, 20);
            this.fechaEsperada.TabIndex = 1;
            // 
            // TxtFecha
            // 
            this.TxtFecha.AutoSize = true;
            this.TxtFecha.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TxtFecha.Location = new System.Drawing.Point(162, 26);
            this.TxtFecha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TxtFecha.Name = "TxtFecha";
            this.TxtFecha.Size = new System.Drawing.Size(52, 13);
            this.TxtFecha.TabIndex = 2;
            this.TxtFecha.Text = "Esperada";
            // 
            // TxtComentario
            // 
            this.TxtComentario.AutoSize = true;
            this.TxtComentario.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TxtComentario.Location = new System.Drawing.Point(26, 56);
            this.TxtComentario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TxtComentario.Name = "TxtComentario";
            this.TxtComentario.Size = new System.Drawing.Size(65, 13);
            this.TxtComentario.TabIndex = 3;
            this.TxtComentario.Text = "Comentarios";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(450, 23);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(210, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // TxtCliente
            // 
            this.TxtCliente.AutoSize = true;
            this.TxtCliente.Location = new System.Drawing.Point(382, 26);
            this.TxtCliente.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TxtCliente.Name = "TxtCliente";
            this.TxtCliente.Size = new System.Drawing.Size(39, 13);
            this.TxtCliente.TabIndex = 5;
            this.TxtCliente.Text = "Cliente";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nombre,
            this.Cantidad});
            this.dataGridView1.Location = new System.Drawing.Point(18, 18);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(309, 123);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 6;
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 200;
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.MinimumWidth = 6;
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.Width = 125;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(34, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Productos";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(25, 50);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(206, 21);
            this.comboBox2.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(277, 28);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Cantidad";
            // 
            // BotonAgregar
            // 
            this.BotonAgregar.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BotonAgregar.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.BotonAgregar.Location = new System.Drawing.Point(145, 97);
            this.BotonAgregar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BotonAgregar.Name = "BotonAgregar";
            this.BotonAgregar.Size = new System.Drawing.Size(86, 33);
            this.BotonAgregar.TabIndex = 11;
            this.BotonAgregar.Text = "Agregar";
            this.BotonAgregar.UseVisualStyleBackColor = false;
            this.BotonAgregar.Click += new System.EventHandler(this.BotonAgregar_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // FormPedidosTitle
            // 
            this.FormPedidosTitle.AutoSize = true;
            this.FormPedidosTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormPedidosTitle.Location = new System.Drawing.Point(37, 23);
            this.FormPedidosTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FormPedidosTitle.Name = "FormPedidosTitle";
            this.FormPedidosTitle.Size = new System.Drawing.Size(121, 24);
            this.FormPedidosTitle.TabIndex = 12;
            this.FormPedidosTitle.Text = "Crear Pedido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(39, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Total sin IVA (€)";
            // 
            // LabelTotal
            // 
            this.LabelTotal.AutoSize = true;
            this.LabelTotal.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LabelTotal.Location = new System.Drawing.Point(196, 27);
            this.LabelTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LabelTotal.Name = "LabelTotal";
            this.LabelTotal.Size = new System.Drawing.Size(13, 13);
            this.LabelTotal.TabIndex = 14;
            this.LabelTotal.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(39, 51);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "IVA (21%)";
            // 
            // LabelIva
            // 
            this.LabelIva.AutoSize = true;
            this.LabelIva.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LabelIva.Location = new System.Drawing.Point(196, 50);
            this.LabelIva.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LabelIva.Name = "LabelIva";
            this.LabelIva.Size = new System.Drawing.Size(13, 13);
            this.LabelIva.TabIndex = 16;
            this.LabelIva.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label8.Location = new System.Drawing.Point(39, 75);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Total a Pagar (€)";
            // 
            // LavelTotalIva
            // 
            this.LavelTotalIva.AutoSize = true;
            this.LavelTotalIva.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LavelTotalIva.Location = new System.Drawing.Point(196, 76);
            this.LavelTotalIva.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LavelTotalIva.Name = "LavelTotalIva";
            this.LavelTotalIva.Size = new System.Drawing.Size(13, 13);
            this.LavelTotalIva.TabIndex = 18;
            this.LavelTotalIva.Text = "0";
            // 
            // BotonFinalizar
            // 
            this.BotonFinalizar.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BotonFinalizar.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.BotonFinalizar.Location = new System.Drawing.Point(524, 442);
            this.BotonFinalizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BotonFinalizar.Name = "BotonFinalizar";
            this.BotonFinalizar.Size = new System.Drawing.Size(158, 39);
            this.BotonFinalizar.TabIndex = 19;
            this.BotonFinalizar.Text = "Crear Predido";
            this.BotonFinalizar.UseVisualStyleBackColor = false;
            this.BotonFinalizar.Click += new System.EventHandler(this.BontonFinalizar_Click);
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBox1.Controls.Add(this.LavelTotalIva);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.LabelIva);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.LabelTotal);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(110, 408);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 101);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Resumen";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.InputCantidad);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.BotonAgregar);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(9, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(380, 158);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Agregar";
            // 
            // InputCantidad
            // 
            this.InputCantidad.Location = new System.Drawing.Point(279, 52);
            this.InputCantidad.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.InputCantidad.Name = "InputCantidad";
            this.InputCantidad.Size = new System.Drawing.Size(62, 20);
            this.InputCantidad.TabIndex = 12;
            // 
            // fechaPedido
            // 
            this.fechaPedido.Location = new System.Drawing.Point(24, 52);
            this.fechaPedido.Name = "fechaPedido";
            this.fechaPedido.Size = new System.Drawing.Size(102, 20);
            this.fechaPedido.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(49, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Pedido";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(282, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Entrega";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(260, 52);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(102, 20);
            this.dateTimePicker2.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(16, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Estado del Pedido";
            // 
            // estadoPedido
            // 
            this.estadoPedido.FormattingEnabled = true;
            this.estadoPedido.Location = new System.Drawing.Point(124, 24);
            this.estadoPedido.Name = "estadoPedido";
            this.estadoPedido.Size = new System.Drawing.Size(194, 21);
            this.estadoPedido.TabIndex = 27;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox3.Controls.Add(this.estadoPedido);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.TxtComentario);
            this.groupBox3.Controls.Add(this.comentarios);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(403, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(345, 89);
            this.groupBox3.TabIndex = 28;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Otros";
            // 
            // Fechas
            // 
            this.Fechas.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Fechas.Controls.Add(this.dateTimePicker2);
            this.Fechas.Controls.Add(this.label5);
            this.Fechas.Controls.Add(this.label3);
            this.Fechas.Controls.Add(this.fechaPedido);
            this.Fechas.Controls.Add(this.TxtFecha);
            this.Fechas.Controls.Add(this.fechaEsperada);
            this.Fechas.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Fechas.Location = new System.Drawing.Point(9, 20);
            this.Fechas.Name = "Fechas";
            this.Fechas.Size = new System.Drawing.Size(380, 89);
            this.Fechas.TabIndex = 29;
            this.Fechas.TabStop = false;
            this.Fechas.Text = "Fechas";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox4.Controls.Add(this.Fechas);
            this.groupBox4.Controls.Add(this.groupBox3);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(7, 60);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(758, 120);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Datos del Pedido";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.groupBox2);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox5.Location = new System.Drawing.Point(7, 191);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(758, 198);
            this.groupBox5.TabIndex = 31;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Productos";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridView1);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox6.Location = new System.Drawing.Point(403, 19);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(344, 158);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Lista de Prodcutos";
            // 
            // Detalles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 531);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BotonFinalizar);
            this.Controls.Add(this.FormPedidosTitle);
            this.Controls.Add(this.TxtCliente);
            this.Controls.Add(this.comboBox1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Detalles";
            this.Text = "Detalles";
            this.Load += new System.EventHandler(this.FormPedidos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputCantidad)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.Fechas.ResumeLayout(false);
            this.Fechas.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox comentarios;
        private System.Windows.Forms.DateTimePicker fechaEsperada;
        private System.Windows.Forms.Label TxtFecha;
        private System.Windows.Forms.Label TxtComentario;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label TxtCliente;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BotonAgregar;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.Label LavelTotalIva;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LabelIva;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label LabelTotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label FormPedidosTitle;
        private System.Windows.Forms.Button BotonFinalizar;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker fechaPedido;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox estadoPedido;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox Fechas;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.NumericUpDown InputCantidad;
    }
}